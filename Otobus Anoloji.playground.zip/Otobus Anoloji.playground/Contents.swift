import UIKit

class Otobus {
    var kapasite:Int?
    var nerden:String?
    var nereye:String?
    var mevcutYolcu:Int?
    
    func yolcuAl(yolcu:Int){
        mevcutYolcu! += yolcu
    }
    
    func yolcuIndir(yolcu:Int){
        mevcutYolcu! -= yolcu
    }
    
    func bilgiAl(){
        print("Kapasite     : \(kapasite!)")
        print("Nereden      : \(nerden!)")
        print("Nereye       : \(nereye!)")
        print("Yolcu Sayısı : \(mevcutYolcu!)")
    }
}

var kamilKoc = Otobus()

kamilKoc.kapasite = 50
kamilKoc.nerden = "Bursa"
kamilKoc.nereye = "Ankara"
kamilKoc.mevcutYolcu = 10

kamilKoc.bilgiAl()

kamilKoc.yolcuAl(yolcu: 10)

kamilKoc.bilgiAl()

kamilKoc.yolcuIndir(yolcu: 5)

kamilKoc.bilgiAl()



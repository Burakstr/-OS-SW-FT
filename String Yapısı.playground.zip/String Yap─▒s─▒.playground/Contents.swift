import UIKit

//Tanımlama

let stringA = "Merhaba"

let stringB = String("Merhaba Nesne")

let stringC = """
Merhaba nasılsınız
Bu bir swift egitimidir

Umarım Faydalı oluyodur...
"""
print(stringA)
print(stringB)
print(stringC)


//Boş Kontrolü

var str1 = "a"

if str1.isEmpty {
    print("str1 boştur")
}else {
    print("str1 boş degildir")
}

var str2 = String()

if str2.isEmpty {
    print("str2 boştur")
}else {
    print("str2 boş degildir")
}
 //Veri Ekleme \()

let a = 20
let b = 100

let str3 = "\(a) x \(b) = \(a*b)"
print(str3)

//String Birleştirme

let str4 = "Merhaba"
let str5 = " Dünya!"

let sonuc = str4 + str5

print(sonuc)

//Boyutu

let str6 = "Merhaba Swift !"

print("\(str6) boyutu : \(str6.count)")

//Karşılaştırma

let str7 = "Merhaba"
let str8 = "Merhaba Dünya"
if str7 == str8 {
    print("\(str7) ve \(str8) eşit")
}else{
    print("\(str7) ve \(str8) eşit degildir")
}

//Parçalama

let str9 = "Merhaba"

for harf in str9 {
    print(harf,terminator:"-")
}

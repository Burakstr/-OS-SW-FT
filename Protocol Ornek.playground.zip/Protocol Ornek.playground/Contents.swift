import UIKit

protocol Squeezable {
    func howtoSqueez()
}
protocol Eatable {
    func howToEat()
}

class Aslan {
    
}

class Tavuk:Eatable {
    func howToEat() {
        print("Fırında Kızart")
    }
}

class Elma:Eatable,Squeezable {
    func howToEat() {
        print("Dilimle ve Ye")
    }
    func howtoSqueez() {
        print("Blendır ile sık")
    }
}

class AmasyaElmasi:Elma {
    override func howToEat() {
        print("Yıka ve ye")
    }
}

var aslan = Aslan()
var amasyaElmasi:Elma = AmasyaElmasi()
var elma = Elma()
var tavuk:Eatable = Tavuk()

var nesneler = [aslan,elma,amasyaElmasi,tavuk] as [Any]

for nesne in nesneler {
    if nesne is Eatable {
        (nesne as! Eatable).howToEat()
    }
    if nesne is Squeezable {
        (nesne as! Squeezable).howtoSqueez()
    }
}

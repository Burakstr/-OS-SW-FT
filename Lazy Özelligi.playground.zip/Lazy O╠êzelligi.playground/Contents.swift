import UIKit

class Ornek {
    lazy var no = 39
}
var nesne = Ornek()

print(nesne.no)

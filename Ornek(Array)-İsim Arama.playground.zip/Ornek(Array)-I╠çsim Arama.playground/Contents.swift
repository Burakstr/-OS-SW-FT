import UIKit

var isimler = ["Ahmet","Mehmet","Zeynep","Serhat","Kadir","Ahmet"]
var kontrolIsim = "Ahmett"

for i in isimler {
    if i == kontrolIsim {
        print("Bu isim dizide mevcuttur.")
        break
    }else{
        print("Böyle bi isim dizide yok")
        break
    }
}

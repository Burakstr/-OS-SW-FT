import UIKit

func kisiTanima(ad:String){
    if ad == "Ahmet" {
        print("Merhaba Ahmet")
    }else{
        print("Tanınmayan Kişi")
    }
}

kisiTanima(ad: "Ahmetx")

func kisiTanima1(ad:String){
    guard ad == "Ahmet" else {
        print("Tanınmayan Kişi")
        return
    }
    print("Merhaba Ahmet")
}
kisiTanima(ad: "Ahmet")

func buyukHarfYap(str:String?){
    if let temp = str {
        print(temp.uppercased())
    }else{
        print("Str nil dir")
        return
    }
}
  
buyukHarfYap(str: nil)


func buyukHarfYap1(str:String?){
    guard let temp = str,temp.count>0 else {
        print("Str nil dir")
        return
    }
    print(temp.uppercased())
}

buyukHarfYap1(str: "nil")

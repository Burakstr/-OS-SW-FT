import UIKit

struct Urun {
    var ad:String?
    var fiyat:Double?
}

class Araba {
    var renk:String?
    var kapasite:Int?
}

var laptop = Urun()

var bmw = Araba()

laptop.ad = "macbook"
laptop.fiyat = 11897.67

print(laptop.ad!)
print(laptop.fiyat!)

laptop.fiyat = 1000.99

print(laptop.fiyat!)

bmw.renk = "Kırmızı"
bmw.kapasite = 4

print(bmw.renk!)
print(bmw.kapasite!)

if let temp = bmw.renk {
    print(temp)
}


var tv = Urun()

tv.ad = "Samsung"
tv.fiyat = 8623.32

var limuzin = Araba()

limuzin.kapasite = 8
limuzin.renk = "beyaz"

print(tv.ad!)
print(tv.fiyat!)

print(limuzin.kapasite!)
print(limuzin.renk!)

import UIKit


class Asinifi {
    static var x = 10
    
    static func metod(){
        print("Merhaba")
    }
}

print(Asinifi.x)

Asinifi.metod()
